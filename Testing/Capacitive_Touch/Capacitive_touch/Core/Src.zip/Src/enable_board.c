#include <stdint.h>
#include "stm32f303xc.h"
#include "enable_board.h"
#include "serial.h"

#define ALTFUNCTION 0xA00
#define RXTX 0x770000
#define HIGHSPEED 0xF00
#define BAUDRATE 0x46
#define LED_OUTPUT 0x5555

// enable the clocks for desired peripherals (GPIOA, C and E)
void enable_clocks() {

	// enable the clocks for peripherals (GPIOA, C and E)
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN | RCC_AHBENR_GPIOCEN | RCC_AHBENR_GPIOEEN;

	// store a 1 in bit for the TIM2 enable flag
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
}

void enable_timer(){

	// Disable the interrupts while messing around with the settings
	// otherwise can lead to strange behavior
	__disable_irq();

	// enable the timer 2 through the RCC registers
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

	// set the prescaler so that 1 count is 1 microsecond
	// 8MHz = 0.000000125, 1 microsecond is 0.000001,
	// prescaler 0.000001/0.000000125 = 8
	TIM2->PSC = 8;  // 1 microsecond / count
	TIM2->ARR = 1000000; // 1 second before reset

	// make the timer2 trigger an interrupt when there is an overflow
	TIM2->DIER |= TIM_DIER_UIE;

	NVIC_EnableIRQ(TIM2_IRQn);
	NVIC_SetPriority(TIM2_IRQn, 2);

	// finally, enable the timer2
	TIM2->CR1 |= TIM_CR1_CEN;

	// Re-enable all interrupts (now that we are finished)
	__enable_irq();
}

void enable_button_interrupt() {
	// Disable the interrupts while messing around with the settings
	//  otherwise can lead to strange behaviour
	__disable_irq();

	// Enable the system configuration controller (SYSCFG in RCC)
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;

	// External Interrupts details on large manual page 294)
	// PA0 is on interrupt EXTI0 large manual - page 250
	// EXTI0 in  SYSCFG_EXTICR1 needs to be 0x00 (SYSCFG_EXTICR1_EXTI0_PA)
	SYSCFG->EXTICR[0] = SYSCFG_EXTICR1_EXTI0_PA;

	//  Select EXTI0 interrupt on rising edge
	EXTI->RTSR |= EXTI_RTSR_TR0; // rising edge of EXTI line 0 (includes PA0)

	// set the interrupt from EXTI line 0 as 'not masked' - as in, enable it.
	EXTI->IMR |= EXTI_IMR_MR0;

	// Tell the NVIC module that EXTI0 interrupts should be handled
	NVIC_SetPriority(EXTI0_IRQn, 3);  // Set Priority
	NVIC_EnableIRQ(EXTI0_IRQn);

	// Re-enable all interrupts (now that we are finished)
	__enable_irq();
}

void enableUSART1()
{
	// Enable GPIO C and USART1's clocks
	RCC->AHBENR |= RCC_AHBENR_GPIOCEN_Msk;
	RCC->APB2ENR |= RCC_APB2ENR_USART1EN_Msk;

	// Set GPIO C to use UART as alternate function
	GPIOC->MODER = ALTFUNCTION;
	GPIOC->AFR[0] = RXTX;
	GPIOC->OSPEEDR = HIGHSPEED;

	// Set the baud rate and ready USART 1 for both receive and transmit
	USART1->BRR = BAUDRATE;                   // Baud rate = 115200
	USART1->CR1 |= USART_CR1_RE_Msk;
	USART1->CR1 |= USART_CR1_TE_Msk;
	USART1->CR1 |= USART_CR1_UE_Msk;
}

void enable_USART1_interrupts()
{
	__disable_irq();

	// Generate an interrupt upon receiving data
	USART1->CR1 |= USART_CR1_RXNEIE_Msk;

	// Set priority and enable interrupts
	NVIC_SetPriority(USART1_IRQn, 1);
	NVIC_EnableIRQ(USART1_IRQn);

	__enable_irq();
}

void enableLEDs()
{
	// Enable clock for Port E (LEDs)
	RCC->AHBENR |= RCC_AHBENR_GPIOEEN;

	// Get the most significant 16 bits of port mode register as that is where the mode for the LEDs are defined
	uint16_t* portMode = ((uint16_t*)&(GPIOE->MODER))+1;

	// Set the mode of the port pins to output since they are LEDs
	*portMode = LED_OUTPUT;

}
